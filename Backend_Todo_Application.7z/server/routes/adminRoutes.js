const router = require('express').Router()

const userController = require('../apis/user/userController')

//const tokenChecker = require('../middleware/tokenChecker')
const taskController = require('../apis/task/taskController')

const multer = require('multer')

//login routes
router.post("/login", userController.login)
//login routes


//----------------------------------middleware------------------------------
 //router.use(require('../middleware/tokenChecker'))
//----------------------------------middleware------------------------------
//task routes
router.post("/task/add", taskController.add)
router.post("/task/all", taskController.all)
router.post("/task/single", taskController.single)
router.post("/task/delete", taskController.del)
//task routes
router.all("*", (req, res) => {
    res.send({
        success: false,
        status: 404,
        message: "Invalid Address"
    })
})

module.exports = router