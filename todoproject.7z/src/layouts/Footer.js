export default function Footer() {

    return (
        <>

            {/* Footer Start */}
            <div
                className="container-fluid  text-white-50 footer pt-5 mt-5 wow fadeIn"
                data-wow-delay="0.1s" style={{ textAlign: 'center', background: '#FE5037', color: 'white' }}
            >
                <div className="container" style={{ color: 'white' }}>
                    <div className="copyright">
                        <div className="row">
                            <div className="col-md-6 text-center text-md-start mb-3 mb-md-0">
                                ©{" "}
                                <b className="bottom" >
                                    {new Date().getFullYear()}
                                </b>
                                , ToDo Application,
                                Stay Organized with &nbsp;
                                <b className="bottom">
                                    TDBuddy
                                </b>
                                <br />
                                Designed By Manisha Kumari
                                <b
                                    className="border-bottom"
                                    target="_blank"
                                >
                                </b>
                            </div>
                            <div className="col-md-6 text-center text-md-end">
                                <div className="footer-menu" style={{ fontSize: '25px' }} >
                                    <i className="fa fa-clipboard-list me-3" />
                                    <b>TDBuddy</b>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            {/* Footer End */}

        </>
    );
}