import { Link } from "react-router-dom";
// import 'bootstrap/dist/css/bootstrap.min.css';
// import 'bootstrap/dist/js/bootstrap.bundle.min.js';
export default function Header() {

    return (
        <>
            <nav className="navbar navbar-expand-lg bg-white navbar-light sticky-top px-4 px-lg-5 py-lg-0">
                <Link href="index.html" className="navbar-brand">
                    <h1 className="m-0 text-primary">
                        <i className="fa fa-clipboard-list me-3" />
                        TDBuddy
                    </h1>
                </Link>
                <button
                    type="button"
                    className="navbar-toggler"
                    data-bs-toggle="collapse"
                    data-bs-target="#navbarCollapse"
                // aria-controls="navbarCollapse"
                // aria-expanded="false"
                // aria-label="Toggle navigation"



                >
                    <span className="navbar-toggler-icon" />
                </button>



                <div className="collapse navbar-collapse" id="navbarCollapse" >
                    <div className="navbar-nav mx-auto">
                        <Link to={"/"} className="nav-item nav-link active">
                            Home
                        </Link>
                        <Link to={"/"} className="nav-item nav-link">
                            Login
                        </Link>
                        <Link to={"/register"} className="nav-item nav-link">
                            Register
                        </Link>
                    </div>
                </div>

            </nav>

        </>
    );
}
