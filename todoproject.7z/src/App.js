import { BrowserRouter, Routes, Route } from 'react-router-dom';
import './App.css';
import Login from './components/Login';
import Register from './components/Register';
import Master from './layouts/Master';
import AdminMaster from './layouts/AdminMaster';
import TaskInput from './components/Task/TaskInput';
import TaskList from './components/Task/TaskList';

function App() {
  return (
    <>
      <BrowserRouter>

        <Routes>
          <Route path={'/'} element={<Master />}>
            <Route path={'/'} element={<Login />} />
            <Route path={'/register'} element={<Register />} />
          </Route>
          <Route path='/user' element={<AdminMaster />}>
            <Route path='/user' element={<TaskInput />} />
            <Route path='/user/task' element={<TaskList />} />
          </Route>
        </Routes>

      </BrowserRouter>
    </>
  );
}
export default App;

