import { Link } from "react-router-dom"
import { useState } from "react"
import { useNavigate } from "react-router-dom"
import { ToastContainer, toast } from 'react-toastify';
export default function Register() {
  const [users, setusers]=useState("")
  const [name, setName] = useState("");
  const [email, setemail] = useState("");
  const [password, setPassword] = useState("")
  const [contact, setcontact] = useState("");
  const nav = useNavigate();
  const handlesubmit = (e) => {
    e.preventDefault();
    if(!email||!name||!password||!contact){
      toast.error("All fields are required");
    }
    else{
      toast.success("Registered Successfully");
      setTimeout(() => {
        nav("/");
    }, 1000)
    }
    const newuser= {
      name: name,
      email: email,
      password: password,
      contact:contact
    }
    setusers([users,newuser]);
    setName('');
    setemail('');
    setPassword('');
    setcontact('');
  }
  
            
  
    
            
  
  return (

    <>
      {/* Register Start */}
      <div className="container-xxl py-5">
        <div className="container">
<ToastContainer/>
          <div
            className="text-center mx-auto mb-5 wow fadeInUp"
            data-wow-delay="0.1s"
            style={{ maxWidth: 600 }}
          >
            <h1 className="mb-3">Create An Account</h1>
          </div>
         
          <div className="bg-light rounded">
            <div className="row g-0">
              <div className="col-lg-3"></div>

              <div className="col-lg-6 wow fadeIn" data-wow-delay="0.1s">
                <div className="h-100 d-flex flex-column justify-content-center p-5">
                  <form>
                    <div className="row g-3">
                      <div className="col-sm-12">
                        <div className="form-floating">
                          <input
                            type="text"
                            className="form-control border-0"
                            id="name"
                            placeholder="Your Name"
                            value={name}
                            onChange={(e) => {
                              setName(e.target.value);
                            }}
                          />
                          <label htmlFor="name">Your Name</label>
                        </div>
                      </div>
                      <div className="col-12">
                        <div className="form-floating">
                          <input
                            type="tel"
                            className="form-control border-0"
                            id="phone" minLength={10} maxLength={10}
                            placeholder="Phone"
                            value={contact}
                            onChange={(e) => {
                              setcontact(e.target.value);
                            }}
                          />
                          <label htmlFor="phone">Phone</label>
                        </div>
                      </div>
                      <div className="col-sm-12">
                        <div className="form-floating">
                          <input
                            type="email"
                            className="form-control border-0"
                            id="email"
                            placeholder="Your Email"
                            value={email}
                            onChange={(e) => {
                              setemail(e.target.value);
                            }}

                          />
                          <label htmlFor="email">Your Email</label>
                        </div>
                      </div>
                      <div className="col-12">
                        <div className="form-floating">
                          <input
                            type="password"
                            className="form-control border-0"
                            id="password"
                            placeholder="Password"
                            value={password}
                            onChange={(e) => {
                              setPassword(e.target.value);
                            }}
                          />
                          <label htmlFor="password">Password</label>
                        </div>
                      </div>
                      <div className="col-12">
                        <button
                          className="btn btn-primary w-100 py-3"
                          type="submit"
                          onClick={handlesubmit}
                          
                          
                        >
                          {/* SignUp */}Register
                        </button>
                      </div>

                      <center>Already have an account?<Link to="/">Log In</Link></center>

                    </div>
                  </form>
                </div>
              </div>
              <div
                className="col-lg-6 wow fadeIn"
                data-wow-delay="0.5s"

              >
              </div>
            </div>
          </div>
        </div>
      </div>
      {/* Register End */}
    </>

  );
}
