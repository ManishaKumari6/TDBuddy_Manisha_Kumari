
import { Link } from "react-router-dom"
import { useState } from "react"
import { useNavigate } from "react-router-dom"
import { ToastContainer, toast } from 'react-toastify';
import ApiServices from "../ApiServices";
export default function Login() {
    const [email, setemail] = useState("");
    const [Password, setPassword] = useState("")
    const nav = useNavigate();
    const handleform = (e) => {
        e.preventDefault();
        let data = {
            email: email,
            password: Password
        }
        ApiServices.Login(data)
            .then((res) => {
                if (res.data.success == true) {
                    console.log(res);
                    if (res.data.data.userType == 1) {
                        sessionStorage.setItem("token", res.data.token);
                        sessionStorage.setItem("email", res.data.data.email);
                        sessionStorage.setItem("_id", res.data.data._id);
                        toast.success("Login Successfully");
                        setTimeout(() => {
                            nav("/user");
                        }, 2000)
                    }
                    if (res.data.data.userType == 2) {
                        sessionStorage.setItem("token", res.data.token);
                        sessionStorage.setItem("email", res.data.data.email);
                        sessionStorage.setItem("_id", res.data.data._id);
                        toast.success("Login Successfully");
                        setTimeout(() => {
                            nav("/user");

                        }, 2000)
                    }

                }
                else {
                    toast.error(res.data.message);
                }
            })
    }
    return (
        <>
            {/* Home Start */}
            <div className="container-xxl py-5">
                <div className="container">
                    <div
                        className="text-center mx-auto mb-5 wow fadeInUp"
                        data-wow-delay="0.1s"
                        style={{ maxWidth: 600 }}
                    >
                        <h1 className="mb-3">Welcome to TDBuddy</h1>
                        <p>
                            Stay Organized with ToDo Application
                            <br></br>
                            Manage your tasks efficiently and never miss deadlines
                        </p>
                    </div>
                </div>

                {/* Home End */}

                {/* Login start*/}

                <div className="container-xxl py-5">
                    <div className="container">

                        <div
                            className="text-center mx-auto mb-5 wow fadeInUp"
                            data-wow-delay="0.1s"
                        >
                            <h1 className="mb-3">Login</h1>
                        </div>

                        <div className="bg-light rounded">
                            <div className="row g-0">
                                <div className="col-lg-3"></div>
                                <div className="col-lg-6 wow fadeIn" data-wow-delay="0.1s">
                                    <div className="h-100 d-flex flex-column justify-content-center p-5">
                                        <form >
                                            <div className="row g-3">
                                                <div className="col-sm-12">
                                                    <div className="form-floating">
                                                        <input
                                                            type="email"
                                                            className="form-control border-0"
                                                            id="email"
                                                            placeholder="Your Email"
                                                            value={email}
                                                            onChange={(e) => {
                                                                setemail(e.target.value);
                                                            }}
                                                        />
                                                        <label htmlFor="email">Your Email</label>
                                                    </div>
                                                </div>
                                                <div className="col-12">
                                                    <div className="form-floating">
                                                        <input
                                                            type="password"
                                                            className="form-control border-0"
                                                            id="password"
                                                            placeholder="Password"
                                                            value={Password}
                                                            onChange={(e) => {
                                                                setPassword(e.target.value);
                                                            }}
                                                        />
                                                        <label htmlFor="password">Password</label>
                                                    </div>
                                                </div>
                                                <div className="col-12">
                                                    <button
                                                        className="btn btn-primary w-100 py-3"
                                                        type="submit"
                                                        onClick={handleform}
                                                    >
                                                        Login
                                                    </button>
                                                </div>
                                            </div>
                                        </form>
                                    </div>
                                </div>
                                <div
                                    className="col-lg-6 wow fadeIn"
                                    data-wow-delay="0.5s"
                                >

                                </div>
                            </div>
                        </div>
                    </div>
                    <ToastContainer />
                    <center>Don't have an account?<Link to="/register">Register</Link></center>
                </div></div>
            {/* Login End */}
        </>
    )
}