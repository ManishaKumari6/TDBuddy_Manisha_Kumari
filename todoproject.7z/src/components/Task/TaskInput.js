import ApiServices from "../../ApiServices";
import { useState } from "react"
import { ToastContainer, toast } from "react-toastify";
export default function TaskInput() {
    const [title, settitle] = useState('');
    const [description, setdescription] = useState('');
    const handleSubmit = (e) => {
        e.preventDefault();
        let data = {
            title: title,
            description:description
        }
        ApiServices.TaskAdd(data)
            .then(res => {
                console.log(res);
                if (res.data.success == true) {
                    toast.success(res.data.message, { position: "top-center" });
                    // localStorage.setItem("title", res.data.title);
                    localStorage.setItem("_id", res.data.data._id);
                    setTimeout(() => {
                        settitle('')
                        window.location.reload();
                    }, 2000)
                }
                else {
                    toast.warning(res.data.message);
                }
            })
            .catch(err => {
                console.log(err);
                toast.error("something went wrong");
            })
    }

    return (
        <>
            {/* Home Start */}
            <div className="container-xxl py-5">
                <div className="container">
                    <div
                        className="text-center mx-auto mb-5 wow fadeInUp"
                        data-wow-delay="0.1s"
                        style={{ maxWidth: 600 }}
                    >
                        <h1 className="mb-3">Welcome to TDBuddy</h1>
                        <p>
                            Stay Organized with ToDo Application
                            <br></br>
                            Manage your tasks efficiently and never miss deadlines
                        </p>
                    </div>
                </div>

                {/* Home End */}
                <div className="container-xxl py-5">
                    <div className="container">

                        <div
                            className="text-center mx-auto mb-5 wow fadeInUp"
                            data-wow-delay="0.1s"
                        >
                            <h1 className="mb-3" >My To Do List</h1>
                        </div>
<ToastContainer/>
                        <div className="bg-light rounded">
                            <div className="row g-0">
                                <div className="col-lg-1"></div>
                                <div className="col-lg-10 wow fadeIn" data-wow-delay="0.1s">
                                    <div className="h-100 d-flex flex-column justify-content-center p-5">
                                        <form>
                                            <div className="row g-3">
                                                <div className="col-sm-12">
                                                    <div className="form-floating">
                                                        <input
                                                            type="text"
                                                            className="form-control border-0"
                                                            id="title"
                                                            placeholder="Task Title"
                                                            value={title} onChange={(e) => { settitle(e.target.value) }}
                                                        />
                                                        <label htmlFor="title">Task Title</label>
                                                    </div>
                                                </div>
                                                <div className="col-sm-12">
                                                    <div className="form-floating">
                                                        <textarea
                                                            type="text"
                                                            className="form-control border-0"
                                                            id="gname"
                                                            placeholder="Gurdian Name"
                                                            value={description} onChange={(e) => { setdescription(e.target.value) }}
                                                        ></textarea>
                                                        <label htmlFor="gname">Task description</label>
                                                    </div>
                                                </div>
                                                <div className="col-12">
                                                    <button
                                                        className="btn btn-primary w-100 py-3"
                                                        type="submit"
                                                        onClick={handleSubmit}

                                                    >
                                                        Add Task
                                                    </button>
                                                </div>
                                            </div>
                                        </form>
                                    </div>
                                </div>
                                <div
                                    className="col-lg-6 wow fadeIn"
                                    data-wow-delay="0.5s"
                                >
                                </div>
                            </div>
                        </div>

                    </div>
                </div></div>
        </>
    );
}