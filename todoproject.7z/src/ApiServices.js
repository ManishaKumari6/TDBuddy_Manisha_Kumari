import axios from "axios"
export const BASE_URL = "http://localhost:5000/"

class ApiServices{
    getToken(){
        let obj={
            Authorization:sessionStorage.getItem('token')
        }
        return obj
    }
    Login(data){
        return axios.post(BASE_URL+"admin/login",data)
    }
    
    Register(data){
    return axios.post(BASE_URL+"customer/register",data);
     }

     TaskAdd(data) {
        return axios.post(BASE_URL + 'admin/task/add', data)
    }
     AllTask(data1) {
        return axios.post(BASE_URL + 'admin/task/all', data1)
    }
     Delete(data) {
         return axios.post(BASE_URL + 'admin/task/delete', data)
     }

}
export default new ApiServices